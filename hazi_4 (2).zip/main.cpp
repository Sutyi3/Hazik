#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

int
gcd (int a, int b)
{
  if (b == 0)
    {
      return a;
    }
  return (b, a & b);
}

int
main ()
{
  int k = 0, ny = 0, sor, oszlop, N, lnko;
  ifstream in ("input.txt");
  ofstream out ("lnko.out");
  in >> N;
  int v[N][N];
  for (sor = 0; sor < N; sor++)
    {
      for (oszlop = 0; oszlop < N; oszlop++)
	{
	  in >> v[sor][oszlop];
	  if (sor > oszlop && sor < N - 1 - oszlop)
	    {
	      ny += v[sor][oszlop];
	    }
	  if (oszlop > sor && oszlop > N - 1 - sor)
	    {
	      k += v[sor][oszlop];
	    }
	}
    }
  lnko = gcd (k, ny);
  out << lnko << endl;
  return 0;
}
