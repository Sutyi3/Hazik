#include <iostream>
using namespace std;

void hanoi(int n, char source, char target, char auxiliary) {
    if (n == 1) {
        cout << n << "." << source << " -> " << target << endl;
        return;
    }
    hanoi(n - 1, source, auxiliary, target);
    cout << n << "." << source << " -> " << target << endl;
    hanoi(n - 1, auxiliary, target, source);
}

int main() {
    int k;
    cin >> k;
    hanoi(k, 'A', 'C', 'B');
    return 0;
}
