#include <iostream>
#include <string>
using namespace std;

int main()
{
    char maganhangzok[] = {'a', 'e', 'i', 'o', 'u'};
    string str1;

    cout << "Mi a szoveg? ";
    getline(cin, str1);

    
    for (char maganhangzo : maganhangzok)
    {
        size_t found = str1.find(maganhangzo);
        while (found != string::npos)
        {
            str1.replace(found, 1, "mpm");
            found = str1.find(maganhangzo, found + 3); 
        }
    }

    size_t pos = str1.find('p');
    while (pos != string::npos)
    {
        str1.insert(pos + 1, "Z");
        pos = str1.find('p', pos + 2); 
    }

    cout << str1 << endl;

    return 0;
}
