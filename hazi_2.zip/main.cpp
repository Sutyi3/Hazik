#include <iostream>
#include <fstream>

using namespace std;


int XFibonacci(int x) {
    if (x <= 0) {
        return 0;
    } else if (x == 1) {
        return 1;
    } else {
        int a = 0, b = 1, c;
        for (int i = 2; i <= x; ++i) {
            c = a + b;
            a = b;
            b = c;
        }
        return b;
    }
}

int main() {
    ifstream inputFile("input.txt");
    ofstream outputFile("fib.out");

    if (!inputFile.is_open() || !outputFile.is_open()) {
        cerr << "Nem sikerült megnyitni a fájlokat!" << endl;
        return 1;
    }

    int n;
    inputFile >> n;
    inputFile.close();


    int x = 0;
    int temp = n;
    while (temp > 0) {
        int digit = temp % 10;
        x = max(x, digit);
        temp /= 10;
    }

    
    int xedikFibonacci = XFibonacci(x);

    
    outputFile << xedikFibonacci << endl;
    outputFile.close();

    cout << "A(z) " << x << ". Fibonacci szám: " << xedikFibonacci << endl;

    return 0;
}
