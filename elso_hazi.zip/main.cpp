#include <iostream>
#include <fstream>
using namespace std;

 
int
main () 
{
  
int i, n, S = 0, temp = 1, veg = 1, atlag, v[1000];
  
ifstream input ("input.txt");
  
ofstream output ("oszto.out");
  
cout << "n= ";
  
input >> n;
  
for (i = 0; i < n; i++)
    {
      
input >> v[i];
      
S = S + v[i];
    
}
  
atlag = S / n;
  
for (i = 1; i < n; i++)
    {
      
if (v[0] < v[i])
	{
	  
v[0] = v[i];
	
}
    
}
  
int a = v[0];
  
while (v[0] > 0)
    {
      
temp = temp * 10;
      
v[0] = v[0] / 10;
    
}
  
int ujszam = atlag * temp + a;
  
for (i = 2; i <= ujszam / 2; i++)
    {
      
if (ujszam % 1 == 0)
	{
	  
veg = 1;
	
}
    
}
  
output << "vegso szam= " << veg;
  
output.close ();
  
return 0;

}
