#include <iostream>

using namespace std;

bool prim(int n) {
  if (n <= 1) return false;
  for (int i = 2; i * i <= n; i++) {
    if (n % i == 0) return false;
  }
  return true;
}

void legnagyobbprimek(int n, int& x, int& y) {
  x = y = -1;
  for (int i = n; i >= 2 && (x == -1 || y == -1); i--) {
    if (prim(i)) {
      if (y == -1) {
        y = i;
      } else if (x == -1) {
        x = i;
      }
    }
  }
}

int main() {
  int n;
  cout << "Mi a felso hatar: ";
  cin >> n;
  int x, y;
  legnagyobbprimek(n, x, y);

  cout << "A két legnagyobb prím szám az [1, " << n << ") intervallumból: " << x << " és " << y << endl;

  return 0; 
}
