#include <iostream>
using namespace std;

 
int
main ()
{
  
int n;
  
cin >> n;
  
 
int count = 0;
  
for (int k = 2; k <= n; ++k)
	{
	  
if (n % k == 0)
		{
		  
++count;
		
}
	
}
  
 
cout << count << endl;
  
return 0;

}


