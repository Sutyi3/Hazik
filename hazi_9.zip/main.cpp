#include <iostream>

using namespace std;

void cuburi(int n){

if(n==0){
    return;
}

cout<<n*n*n<<" ";

return cuburi(n-1);

}

int main()
{
    int n;
    cin>>n;
    cuburi(n);
    return 0;
}
