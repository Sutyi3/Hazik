#include <iostream>
#include <fstream>

using namespace std;


int
main ()
{
  int k = 0, ny = 0, sor, oszlop, N, lnko;
  ifstream in ("input.txt");
  ofstream out ("lnko.out");
  in >> N;
  int v[N][N];
  for (sor = 0; sor < N; sor++)
    {
      for (oszlop = 0; oszlop < N; oszlop++)
	{
	  in >> v[sor][oszlop];
	  if (sor < oszlop && sor + oszlop > N - 1)
	    {
	      ny += v[sor][oszlop];
	    }
	  if (sor > oszlop && sor + oszlop < N - 1)
	    {
	      k += v[sor][oszlop];
	    }
	}
    }
  if(k>ny){
      int aux=k;
      k=ny;
      ny=aux;
  }
  for(int i=1; i<=k; i++){
      if(ny%i==0 && k%i==0){
          lnko=i;
      }  
      
  }
  out<<lnko<<endl;
  return 0;
}
