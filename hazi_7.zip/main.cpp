#include <iostream>
#include <cmath>


bool prim(int n) {
    if (n <= 1)
        return false;
    if (n == 2)
        return true;
    if (n % 2 == 0)
        return false;
    for (int i = 3; i * i <= n; i += 2)
        if (n % i == 0)
            return false;
    return true;
}

int hatvany(int n) {
    int min_prim = n;
    int min_darab = n;
    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0 && prim_e(i)) {
            int darab = 0;
            while (n % i == 0) {
                n /= i;
                darab++;
            }
            if (darab < min_darab) {
                min_darab = darab;
                min_prim = i;
            }
        }
    }
    if (n > 1 && prim_e(n) && 1 < min_darab) {
        min_prim = n;
    }
    return min_prim;
}

int main() {
    int n;
    std::cout << "Mi a szam: ";
    std::cin >> n;
    std::cout << "A legkisebb primszam, amely a legkisebb hatvanyon jelenik meg az n szam primtenyezoi kozott: " << hatvany(n) << std::endl;
    return 0;
}
