#include <iostream>
#include <string>
using namespace std;

int
main ()
{
  string str1;
  int k, i, j;
  cout << "A szo: ";
  cin >> str1;
  cout << "Hanyszor forgassuk el a szot? ";
  cin >> k;
  int size = str1.size ();
  if (k <= 5)
    {
      for (i = 0; i < k; i++)
	{
	  char malata = str1[size - 1];
	  for (j = size; j > 0; j--)
	    {
	      str1[j] = str1[j - 1];
	    }
	  str1[0] = malata;
	}
    }
  cout << str1;

  return 0;
}
