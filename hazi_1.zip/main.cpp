#include <iostream>
#include <fstream>
using namespace std;

int
main () 
{
  
int i, j, n, arr[1000], min, temp = 1, S = 0, avg, vegsoszam = 1;
  
 
ifstream in ("input.txt");
  
ofstream out ("oszto.out");
  
in >> n;
  
for (i = 0; i < n; i++)
    {
      
in >> arr[i];
      
S = S + arr[i];
    
}
  
avg = S / n;
  
 
for (i = 0; i < n - 1; i++)
    {
      
min = i;
      
for (j = i + 1; j < n; j++)
	{
	  
if (arr[j] < arr[i])
	    {
	      
min = j;
	    
}
	
}
      
if (min != i)
	{
	  
swap (arr[i], arr[min]);
	
}
    
}
  
 
int x = arr[i];
  
while (arr[i] > 0)
    {
      
temp = temp * 10;
      
arr[i] = arr[i] / 10;
    
}
  
int ujszam = avg * temp + x;
  
 
for (int i = 2; i <= ujszam / 2; i++)
    {
      
if (ujszam % i == 0)
	{
	  
vegsoszam = i;
	
}
    
}
  
out << "vegsoszam = " << vegsoszam;
  
out.close ();
  
 
return 0;

}
