#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int main()
{
    int sor, oszlop, N, lkkt = 1, fa = 0, ff = 0;
    ifstream in("input.txt");
    in >> N;
    int v[N][N];
    for (sor = 0; sor < N; sor++)
    {
        for (oszlop = 0; oszlop < N; oszlop++)
        {
            in >> v[sor][oszlop];

            if (sor < oszlop)
            {
                ff += v[sor][oszlop];
            }
            if (sor > oszlop)
            {
                fa += v[sor][oszlop];
            }
        }
    }

    while (ff != fa)
    {
        if (lkkt % ff == 0 && lkkt % fa == 0)
        {
            break;
        }
        lkkt++;
    }

    ofstream lkkt_out("lkkt.out");
    lkkt_out << lkkt;

    return 0;
}
